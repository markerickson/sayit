//
//  ViewController.h
//  SayIt
//
//  Created by Doreen Theverapperuma on 9/29/13.
//  Copyright (c) 2013 DCT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
